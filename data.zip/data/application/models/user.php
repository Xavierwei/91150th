<?php

Class User extends Eloquent {
	public static $table = "user";
	public static $key = "uid";
}