<?php

class GameRecord extends Eloquent {
	public static $table = "game_record";
	public static $key = "grid";
}