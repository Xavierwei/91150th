<?php namespace Laravel\CLI\Tasks;

abstract class Task {}